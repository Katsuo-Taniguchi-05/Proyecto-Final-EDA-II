# Clase Grafo Base que define los metodos de la implementacion

class GrafoBase: 
    
    # Constructor de la estructura base del grafo
    def __init__(self, n, dirigido = False):
        raise NotImplementedError
        
    # Agrega una arista entre los vertices u y v
    def agregarArista(self, u, v):
        raise NotImplementedError
        
    # Ordena los vertices por grado de mayor a menor, para ser asignada las frecuencias y colores
    def ordenarVerticesXGrado(self):
        raise NotImplementedError
    
    # Asigna las frecuencias y colores a las antenas en orden de mayor grado
    def asignarFrecuencias(self, listaFrecuencias):
        raise NotImplementedError
        
    # Valida la condicion de que no ningun par de vecinos tengan el mismo color
    def validarColoresVecinos(self, asignados):
        raise NotImplementedError
        
    #Calcula el numero cromatico del grafo
    def calcularNumeroCromatico(self, listaColores):
        raise NotImplementedError
        
    # Limpia la informacion del grafo
    def reiniciarAsignaciones(self):
        raise NotImplementedError
            