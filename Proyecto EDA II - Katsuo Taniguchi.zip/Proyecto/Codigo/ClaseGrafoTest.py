from ClaseGrafoImp import Grafo
from ClaseAntena import Antena

# Clase para probar la implementacion del grafo (Estructura base y metodos)

def main():
    
    # Creacion de la instancia Grafo no dirigido con 5 vertices (Antenas) 
    redAntenas = Grafo(5, dirigido=False)
    
    # Agregar las aristas del del grafo 
    redAntenas.agregarArista("Antena1", "Antena2")
    redAntenas.agregarArista("Antena2", "Antena3")
    redAntenas.agregarArista("Antena3", "Antena4")
    redAntenas.agregarArista("Antena4", "Antena5")
    redAntenas.agregarArista("Antena5", "Antena1")
    
    # Pruebas de los metodos: 
    # Imprimir lista de adyacencia
    print("Lista de adyacencia:")
    for nodo, vecinos in redAntenas.listaAdyacencia.items():
        print(f"{nodo} -> {vecinos}")
    
    
    # Probar detección de ciclo BFS
    tiene_ciclo = redAntenas.detectarCicloBFS()
    print("\n¿Tiene ciclo?:", tiene_ciclo)
    
    # Probar asignarFrecuencias con un conjunto de frecuencias
    listaFrecuencias = [903, 3300, 1300, 850, 2335]
    redAntenas.asignarFrecuencias(listaFrecuencias)
    print("\nAsignación de frecuencias y colores:")
    for antena_id, antena in redAntenas.antenas.items():
        print(f"{antena_id} => Frecuencia: {antena.frecuencia} MHz, Color: {antena.color}")
    
    # Probar coloreado_Greedy con la lista de colores
    asignacion_colores = redAntenas.coloreado_Greedy(redAntenas.colores)
    print("\nAsignación de colores:", asignacion_colores)
    
    # Probar el calculo del numero cromatico
    num_cromatico = redAntenas.calcularNumeroCromatico(redAntenas.colores)
    print("\nNúmero cromático estimado:", num_cromatico)
    
    # Verificar que ninguna antena vecina comparta color
    valid = redAntenas.validarColoresVecinos(asignacion_colores)
    print("\nValidación de colores entre vecinos:", valid)
    
    #Limpiar los valores de frecuencia y color del grafo
    redAntenas.reiniciarAsignaciones()
    for antena_id, antena in redAntenas.antenas.items():
        print(f"{antena_id} => Frecuencia: {antena.frecuencia}, Color: {antena.color}")
        
if __name__ == "__main__":
    main()
    
