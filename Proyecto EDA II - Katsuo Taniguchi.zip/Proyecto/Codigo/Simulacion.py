import time
from ClaseGrafoImp import Grafo
from Visualizacion import visualizarGrafo
import matplotlib.pyplot as plt

# Funcion para leer frecuencias desde el archivo txt
def leerFrecuenciasArchivo(frecuencias):
    frecuencias_extraidas = []
    # Abrimos el archivo y lo leemos
    archivo = open("frecuencias.txt", 'r')
    lineas = archivo.readlines()
    for linea in lineas:
        linea = linea.strip()
        frecuencia = int(linea)
        frecuencias_extraidas.append(frecuencia)
    return frecuencias_extraidas

# Funcion principal para ejecutar la simulacion
def simularTandas(grafo: Grafo, listaFrecuencias, tamanioTanda = 5, duracionTanda = 5):
    resultados = [] #Almacenamos el numero cromático de cada tanda
    totalFrecuencias = len(listaFrecuencias) 
    numeroTandas = totalFrecuencias//tamanioTanda
    
    #Modo iterativo de la libreria matplotlib
    plt.ion()
    fig = plt.figure(1)
    # Establecemos las tandas de la simulacion usando un bucle hasta el numero de tandas a simular
    for i in range(numeroTandas):
        fig.clf() #Limpia el grafico
        print(f"\nTanda {i+1}/{numeroTandas}")
        grafo.reiniciarAsignaciones() # Reiniciamos las asignaciones entre cada tanda
        tanda = listaFrecuencias[i*tamanioTanda : (i+1)*tamanioTanda] # Extraemos el subconjunto de frecuencias a seer asignadas
        print("Frecuencias de la tanda: ", tanda)
        # Asignamos las frecuencias usando el algortimo implementado
        grafo.asignarFrecuencias(tanda)
        # Calculamos el numero cromatico de la tanda
        numeroCromaticoTanda = grafo.calcularNumeroCromatico(grafo.colores)
        # Mostramos el gráfico 
        visualizarGrafo(grafo, mostrarColor = True, titulo_grafico =f"Tanda {i+1}")
        # except Exception as error:
        #     print("Error en asignacion de frecuencias: ", error)
        #     break
        print("\nAsignación de frecuencias y colores:")
        for antena_id, antena in grafo.antenas.items():
            print(f"{antena_id} => Frecuencia: {antena.frecuencia} MHz, Color: {antena.color}")
        
        print("Numero cromatico de la tanda: ", numeroCromaticoTanda)
        resultados.append(numeroCromaticoTanda)
        
        plt.pause(duracionTanda)
        #plt.close()
    
    plt.ioff()
    plt.show()
    plt.close() 
    return resultados

def main():
    # Crear grafo y configurar estructura (aristas, etc.)
    # 1. Crear grafo con 10 antenas
    grafo = Grafo(10, dirigido=False)
    
    # Antena 1 conectada a 2, 3, 4, 5
    grafo.agregarArista("Antena1", "Antena2")
    grafo.agregarArista("Antena1", "Antena3") 
    grafo.agregarArista("Antena1", "Antena4") 
    grafo.agregarArista("Antena1", "Antena5") 

    # Antena 2 conectada a 3, 4, 5
    grafo.agregarArista("Antena2", "Antena3") 
    grafo.agregarArista("Antena2", "Antena4") 
    grafo.agregarArista("Antena2", "Antena5") 

    # Antena 3 conectada a 4, 5
    grafo.agregarArista("Antena3", "Antena4") 
    grafo.agregarArista("Antena3", "Antena5") 

    # Antena 4 conectada a 5
    grafo.agregarArista("Antena4", "Antena5") 

    # Conectar 5 con 6
    grafo.agregarArista("Antena5", "Antena6") 

    # Generar ciclos
    grafo.agregarArista("Antena6", "Antena7")
    grafo.agregarArista("Antena7", "Antena8")
    grafo.agregarArista("Antena8", "Antena9")
    grafo.agregarArista("Antena9", "Antena10")
    
    # Conectar 6 con 10 atravesando el grafo
    grafo.agregarArista("Antena6", "Antena10")

    
    listaFrecuencias = leerFrecuenciasArchivo("frecuencias.txt")
    
    resultados = simularTandas(grafo, listaFrecuencias, tamanioTanda = 20, duracionTanda = 4)
    print("\nLista de numeros cromaticos por tanda: ", resultados)
        
if __name__ == "__main__":
    main()
    
    
    
