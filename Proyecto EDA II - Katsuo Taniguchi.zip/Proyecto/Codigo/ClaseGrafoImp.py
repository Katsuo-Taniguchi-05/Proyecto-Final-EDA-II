from ClaseGrafoBase import GrafoBase
from collections import deque
from ClaseAntena import Antena

# Funcion auxiliar que obtiene el grado de un vertice a partir de una tupla
# Se utiliza esta funcion en el metodo de ordenarVerticesXGrado
def obtenerGrado(tuplaVertice):
    return tuplaVertice[1]
    
# Funcion auxiliar que asigna el color para una frecuencia dada
def asignarColorXFrecuencia(frecuencia):
    if 800 <= frecuencia <= 1200:
        return "Rojo"
    elif 1201 <= frecuencia <= 1600:
        return "Azul"
    elif 1601 <= frecuencia <= 2000:
        return "Verde"
    elif 2001 <= frecuencia <= 2400:
        return "Naranja"
    elif 2401 <= frecuencia <= 2800:
        return "Morado"
    elif 2801 <= frecuencia <= 3200:
        return "Marron"
    elif 3201 <= frecuencia <= 3600:
        return "Gris"
    else:
        return None

# Clase Grafo donde se implementan los metodos 
class Grafo(GrafoBase):
    # Constructor del grafo
    def __init__(self, n, dirigido = False):
        self.numVertices = n
        self.dirigido = dirigido
        
        # Se utilizo un diccionario para almacenar los objetos Antena, usando ID como clave
        self.antenas = {f"Antena{i+1}" : Antena(f"Antena{i+1}") for i in range(n)}
        
        # Se utilizo una lista de adyacencia (diccionario de listas)
        self.listaAdyacencia = {key : [] for key in self.antenas}
        
        # Lista de colores (solo para referencia en el mapeo de frecuencia)
        self.colores = ["Rojo", "Azul", "Verde", "Naranja", "Morado", "Marron", "Gris"]
        
    # Agrega una arista entre las antenas x e y
    def agregarArista(self, x, y):
        if x not in self.listaAdyacencia or y not in self.listaAdyacencia:
            raise ValueError("Los vertices no existen en el grafo")
        self.listaAdyacencia[x].append(y)
        
        # Cuando no es dirigido: 
        if not self.dirigido:
            self.listaAdyacencia[y].append(x)
        
    # Algoritmo 1: Calcula el grado de cada vertice y los ordena de mayor a menor. 
    def ordenarVerticesXGrado(self):
        # Lista para almacenar los vertices con sus grados correspondientes
        listaVerticesXGrado = []
        
        # Bucle para recorrer el vertice y sus vecinos en la lista de adyacencia
        for vertice, vecinos in self.listaAdyacencia.items():
            grado = len(vecinos)
            listaVerticesXGrado.append((vertice, grado))
        
        # Ordenar los vertices segun grado. (De mayor a menor)
        listaVerticesXGrado.sort(key = obtenerGrado , reverse=True)
        
        # Se extrae el id de la antena (vertice) segun el orden de grados
        nodosOrdenados = [vertice for (vertice, grado) in listaVerticesXGrado]
        return nodosOrdenados
    
    # Algoritmo 2: Asigna las frecuencias y colores a las antenas en orden de mayor grado (Algortimo de Welsh-Powell), 
    # usando la logica voraz (Greedy) y la restriccion de no reuso por tanda.
    def asignarFrecuencias(self, listaFrecuencias):
        nodosOrdenados = self.ordenarVerticesXGrado()
        # Estructura Set O(1) para verificar no reuso en la tanda
        frecuenciasUsadas = set() 
        print("Orden de las antenas para su asignacion: ", nodosOrdenados)
        
        # Bucle para recorrer todas la Antenas (nodos)
        for antena_ID in nodosOrdenados:
            antena = self.antenas[antena_ID]
            print(f"Asignando a antena {antena_ID}...")
            antenaAsignada = False
            
            # Bucle para recorrer la lista de frecuencias
            for frecuencia in listaFrecuencias:
                # Restriccion 1: No reutilizar frecuencia en la tanda (Uso del Set)
                if frecuencia in frecuenciasUsadas:
                    continue
                    
                colorActual = asignarColorXFrecuencia(frecuencia)
                if colorActual is None:
                    print(f"Frecuencia {frecuencia} MHz fuera del rango del color.")
                    continue
                    
                interferencia = False
                # Bucle para recorrer la lista de vecinos de la Antena 
                # Restriccion 2: No interferencia (Coloreo de Vecinos)
                for vecino_ID in self.listaAdyacencia[antena_ID]:
                    # Agarramos al vecino para realizar la comparacion
                    vecino = self.antenas[vecino_ID]
                    if vecino.color == colorActual:
                        interferencia = True
                        break
                        
                # Si hay interferencia (vecino con el mismo color): 
                if interferencia:
                    print(f"Frecuencia {frecuencia} MHz -> color {colorActual} interfiere con vecino de {antena_ID}")
                    continue
                    
                # Si no hay interferencia (vecino con diferente color y no usada): 
                antena.frecuencia = frecuencia # Asignamos la frecuencia a la antena
                antena.color = colorActual # Asignamos el color a la antena
                frecuenciasUsadas.add(frecuencia)
                print(f"Frecuencia {frecuencia} MHz asignada -> color {colorActual} a {antena_ID}")
                antenaAsignada = True
                break
                
            if not antenaAsignada:
                raise Exception(f"No se pudo asignar ninguna frecuencia válida para {antena_ID}")
                
    # Algoritmo 3: Valida la condicion de que no ningun par de vecinos tengan el mismo color
    def validarColoresVecinos(self, asignados):
        # Complejidad O(E)
        for x, vecinos in self.listaAdyacencia.items():
            for y in vecinos:
                #Si los nodos X y Y tienen el mismo color la asignacion es invalida
                if asignados.get(x) == asignados.get(y):
                    # Si asignados.get(x) es None (unassigned), no hay interferencia.
                    # El problema ocurre si ambos tienen un color asignado E IGUAL.
                    if asignados.get(x) is not None:
                        return False
        return True
        
    # Algoritmo 3 (Metrica): Calcula el numero cromatico del grafo
    def calcularNumeroCromatico(self, listaColores):
        asignacion = {}
        for antena_ID, antena in self.antenas.items():
            if antena.color is not None:
                asignacion[antena_ID] = antena.color
                
        # 1. Validamos la condición de que no ningun par de vecinos tengan el mismo color
        if not self.validarColoresVecinos(asignacion):
            # Esta excepción es la que te indica que la *tanda* falló.
            raise Exception("INTERFERENCIA!!! La asignación de frecuencias de la Tanda viola la regla de coloreo.")
            
        # 2. Contamos los colores únicos usados (Número Cromático)
        # Uso del Set para conteo O(V)
        colores_usados = set(asignacion.values())
            
        # Devolvemos el numero de colores que no han sido repetidos
        return len(colores_usados)
        
    # Limpia las asignaciones de frecuencia y color de todas las antenas para regenerar el Grafo
    def reiniciarAsignaciones(self):
        # Bucle para recorrer todas las antenas del grafo
        for antena in self.antenas.values():
            antena.frecuencia = None
            antena.color = None
        
        
            
        
            
        
        
