import matplotlib.pyplot as plt 
import networkx as nx
from ClaseGrafoImp import Grafo
from ClaseAntena import Antena

# Se utilizaron las librerias de matplotlib.pyplot y networkx para generar el grafico (plot) del grafo de red de Antenas

# Diccionario con la traduccion de los colores para que funcione la libreria Matplotlib y networkx
colores_traducidos = {
        "Rojo": "red",
        "rojo": "red",
        "Azul": "blue",
        "azul": "blue",
        "Verde": "green",
        "verde": "green",
        # "Amarillo": "yellow",
        # "amarillo": "yellow",
        "Naranja": "orange",
        "naranja": "orange",
        "Morado": "purple",
        "morado": "purple",
        "Marron": "brown",
        "marron": "brown",
        "Gris": "gray",
        "gris": "gray"
    }

# Diccionario de posiciones fijas (ejemplo para un diseño circular o de clúster)
# Coordenadas (X, Y)
posiciones_antenas = {
    "Antena1": (0, 1),
    "Antena2": (0.95, 0.31),
    "Antena3": (0.59, -0.81),
    "Antena4": (-0.59, -0.81),
    "Antena5": (-0.95, 0.31),
    
    # Resto de antenas (6 a 10)
    "Antena6": (1.2, 1),  # Conectado a A5
    "Antena7": (2.0, 0.0),
    "Antena8": (1.5, -0.9),
    "Antena9": (0.5, -1.5),
    "Antena10": (-0.5, -1.5)
}

# Funcion para dibujar el grafo de antenas. Recibe un grafo y el parametro booleano de mostrar colores 
def visualizarGrafo(grafo: Grafo, mostrarColor=True, titulo_grafico = "Visualizacion de red de antenas"):
    
    # Crear el objeto grafo usando el metodo de la libreria NetworkX
    redAntenasMovil = nx.Graph() if not grafo.dirigido else nx.DiGraph()
    
    # Agrega los nodos al objeto grafo creado
    # Bucle para recorrer todos los nodos y vecinos del grafo (Antena1, [Vecino1, Vecino2])
    for nodo, vecinos in grafo.listaAdyacencia.items():
        #print(grafo.listaAdyacencia.items())
        redAntenasMovil.add_node(nodo)
        
    # Agregar las aristas del grafo    
    for nodo, vecinos in grafo.listaAdyacencia.items():
        for vecino in vecinos:
            # Si no es dirigido, agregar la arista solo 1 vez
            if not grafo.dirigido:
                if nodo < vecino:
                    redAntenasMovil.add_edge(nodo, vecino)
                
            else: 
                redAntenasMovil.add_edge(nodo, vecino)
    
    # Obtener los colores de los nodos
    if mostrarColor: 
        # Extraer el color asignado de cada antena y compararlo con el diccionario de colores 
        # traducidos para establecer el color segun los reconocidos por la libreria Matplotlib
        color_nodos = [colores_traducidos.get(grafo.antenas[nodo].color, "pink") 
                       for nodo in grafo.antenas]
    else: 
        color_nodos = "Gray"
        
    # Etiquetas a cada antena para que salga con su frecuencia
    etiquetas = {}
    for nodo_id, antena in grafo.antenas.items():
        # Formato: AntenaID\n(Freq: XXXX MHz)
        freq_str = f"Freq: {antena.frecuencia} MHz" if antena.frecuencia is not None else "Sin Freq."
        etiquetas[nodo_id] = f"{nodo_id}\n({freq_str})"    
    
    # Dibujar el grafo usando el metodo spring layaout para una mejor distribucion
    # pos = nx.spring_layout(redAntenasMovil)
    if grafo.numVertices == 10 and all(antena in posiciones_antenas for antena in grafo.antenas):
        pos = posiciones_antenas
    else:
        # Usa el diseño aleatorio solo si el número de antenas es diferente a 10
        pos = nx.spring_layout(redAntenasMovil)
    nx.draw(
            redAntenasMovil, 
            pos, 
            with_labels = True, # Mantenemos False ya que usamos el parametro 'labels'
            labels = etiquetas, 
            node_color = color_nodos, 
            node_size = 1000, 
            font_size = 8, 
            font_color = 'black'
        )
    
    # Mostrar el título corregido 
    plt.title(titulo_grafico)
    plt.draw() # Mostrar el grafo en una ventana
    
def main():
    # Crear ejemplo
    grafo = Grafo(5, dirigido=False)
    grafo.agregarArista("Antena1", "Antena2")
    grafo.agregarArista("Antena2", "Antena3")
    grafo.agregarArista("Antena3", "Antena4")
    grafo.agregarArista("Antena4", "Antena5")
    grafo.agregarArista("Antena5", "Antena1")

    # Asignar frecuencias ejemplo
    listaFrecuencias = [902, 2500, 3300, 807, 1200, 900, 3000, 1600, 2700, 3500]
    grafo.asignarFrecuencias(listaFrecuencias)
    
    print("\nAsignación de frecuencias y colores:")
    for antena_id, antena in grafo.antenas.items():
        print(f"{antena_id} => Frecuencia: {antena.frecuencia} MHz, Color: {antena.color}")
        
    # Visualizar
    visualizarGrafo(grafo, mostrarColor=True)

if __name__ == "__main__":
    main()
        
    